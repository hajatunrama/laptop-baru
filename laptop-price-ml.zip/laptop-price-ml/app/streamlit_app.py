"""
Laptop Price Predictor — Streamlit App
Menampilkan eksplorasi data (EDA) dan prediksi harga laptop
menggunakan model ML terbaik (Linear Regression / Random Forest / XGBoost).
"""

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = ROOT / "data" / "dataset_laptop_realistis.csv"
MODEL_PATH = ROOT / "models" / "best_model.pkl"
METRICS_PATH = ROOT / "models" / "metrics.json"
META_PATH = ROOT / "models" / "feature_meta.json"

st.set_page_config(
    page_title="Laptop Price Predictor",
    page_icon="💻",
    layout="wide",
)

# ---------- Custom styling ----------
st.markdown(
    """
    <style>
    .stApp { background-color: #0E1117; }
    .metric-card {
        background: #1A1C24;
        border: 1px solid #2A2D3A;
        border-radius: 12px;
        padding: 18px 20px;
    }
    h1, h2, h3 { letter-spacing: -0.02em; }
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_data
def load_data():
    return pd.read_csv(DATA_PATH)


@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)


@st.cache_data
def load_metrics():
    with open(METRICS_PATH) as f:
        return json.load(f)


@st.cache_data
def load_meta():
    with open(META_PATH) as f:
        return json.load(f)


df = load_data()
model = load_model()
metrics = load_metrics()
meta = load_meta()

st.title("💻 Laptop Price Predictor")
st.caption(
    "Dashboard eksplorasi data & prediksi harga laptop menggunakan Machine Learning "
    f"— model terbaik: **{metrics['best_model']}**"
)

tab_overview, tab_eda, tab_predict = st.tabs(
    ["📊 Ringkasan Model", "🔍 Eksplorasi Data", "🎯 Prediksi Harga"]
)

# ============================================================
# TAB 1: Overview / model comparison
# ============================================================
with tab_overview:
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("Jumlah Data", f"{len(df):,}")
        st.markdown("</div>", unsafe_allow_html=True)
    with col2:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("Model Terbaik", metrics["best_model"])
        st.markdown("</div>", unsafe_allow_html=True)
    with col3:
        best_r2 = metrics["results"][metrics["best_model"]]["R2"]
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("R² Score", f"{best_r2:.4f}")
        st.markdown("</div>", unsafe_allow_html=True)

    st.subheader("Perbandingan Algoritma")
    results_df = pd.DataFrame(metrics["results"]).T.reset_index()
    results_df.columns = ["Model", "R2", "MAE", "RMSE"]
    results_df = results_df.sort_values("R2", ascending=False)

    fig = px.bar(
        results_df,
        x="Model",
        y="R2",
        text="R2",
        color="Model",
        title="R² Score per Model (semakin tinggi semakin baik)",
        color_discrete_sequence=px.colors.qualitative.Set2,
    )
    fig.update_traces(texttemplate="%{text:.4f}", textposition="outside")
    fig.update_layout(showlegend=False, yaxis_range=[0, 1.05])
    st.plotly_chart(fig, use_container_width=True)

    st.dataframe(results_df.set_index("Model"), use_container_width=True)

    st.info(
        "Ketiga model (Linear Regression, Random Forest, XGBoost) dilatih dan "
        "dievaluasi dengan train-test split 80/20. Model dengan R² tertinggi "
        "otomatis dipilih sebagai model produksi (`models/best_model.pkl`)."
    )

# ============================================================
# TAB 2: EDA
# ============================================================
with tab_eda:
    st.subheader("Distribusi Harga Laptop")
    c1, c2 = st.columns(2)
    with c1:
        fig1 = px.histogram(df, x="Price (USD)", nbins=40, color_discrete_sequence=["#6C63FF"])
        fig1.update_layout(title="Distribusi Harga")
        st.plotly_chart(fig1, use_container_width=True)
    with c2:
        fig2 = px.box(df, x="Usage Type", y="Price (USD)", color="Usage Type",
                       color_discrete_sequence=px.colors.qualitative.Set2)
        fig2.update_layout(title="Harga berdasarkan Tipe Penggunaan", showlegend=False)
        st.plotly_chart(fig2, use_container_width=True)

    c3, c4 = st.columns(2)
    with c3:
        fig3 = px.scatter(
            df, x="Total Performance", y="Price (USD)", color="Usage Type",
            hover_data=["Laptop Brand", "Laptop Model"],
            color_discrete_sequence=px.colors.qualitative.Set2,
        )
        fig3.update_layout(title="Total Performance vs Harga")
        st.plotly_chart(fig3, use_container_width=True)
    with c4:
        avg_price_brand = df.groupby("Laptop Brand")["Price (USD)"].mean().sort_values(ascending=False).reset_index()
        fig4 = px.bar(
            avg_price_brand, x="Laptop Brand", y="Price (USD)",
            color="Laptop Brand", color_discrete_sequence=px.colors.qualitative.Set2,
        )
        fig4.update_layout(title="Rata-rata Harga per Brand", showlegend=False)
        st.plotly_chart(fig4, use_container_width=True)

    st.subheader("Korelasi Fitur Numerik")
    numeric_cols = df.select_dtypes(include=np.number).columns
    corr = df[numeric_cols].corr()
    fig5 = px.imshow(
        corr, text_auto=".2f", color_continuous_scale="RdBu_r", aspect="auto",
        title="Correlation Heatmap",
    )
    st.plotly_chart(fig5, use_container_width=True)

    with st.expander("Lihat data mentah"):
        st.dataframe(df, use_container_width=True)

# ============================================================
# TAB 3: Prediction form
# ============================================================
with tab_predict:
    st.subheader("Masukkan Spesifikasi Laptop")

    with st.form("predict_form"):
        colA, colB, colC = st.columns(3)

        with colA:
            country = st.selectbox("Country", meta["Country"])
            brand = st.selectbox("Laptop Brand", meta["Laptop Brand"])
            laptop_model = st.selectbox("Laptop Model", meta["Laptop Model"])
            usage_type = st.selectbox("Usage Type", meta["Usage Type"])

        with colB:
            cpu_brand = st.selectbox("CPU Brand", meta["CPU Brand"])
            gpu_brand = st.selectbox("GPU Brand", meta["GPU Brand"])
            gpu_model = st.selectbox("GPU Model", meta["GPU Model"])
            ram = st.select_slider("RAM (GB)", options=sorted(set(int(x) for x in np.linspace(*meta["numeric_ranges"]["RAM (GB)"], 10))), value=16)

        with colC:
            cpu_cores = st.slider("CPU Cores", 2, 16, 8)
            cpu_threads = st.slider("CPU Threads", 2, 32, 16)
            base_clock = st.slider("Base Clock (GHz)", 1.0, 3.5, 2.2, 0.01)
            boost_clock = st.slider("Boost Clock (GHz)", 2.0, 5.5, 4.0, 0.01)

        colD, colE, colF = st.columns(3)
        with colD:
            tdp = st.slider("TDP (W)", 10, 100, 35)
        with colE:
            storage = st.select_slider("Storage (GB)", options=[128, 256, 512, 1024, 2048], value=512)
        with colF:
            total_perf = st.slider(
                "Total Performance (estimasi)",
                int(meta["numeric_ranges"]["Total Performance"][0]),
                int(meta["numeric_ranges"]["Total Performance"][1]),
                6000,
            )

        cpu_perf = st.slider(
            "CPU Performance (estimasi)",
            int(meta["numeric_ranges"]["CPU Performance"][0]),
            int(meta["numeric_ranges"]["CPU Performance"][1]),
            3000,
        )
        gpu_perf = st.slider(
            "GPU Performance (estimasi)",
            int(meta["numeric_ranges"]["GPU Performance"][0]),
            int(meta["numeric_ranges"]["GPU Performance"][1]),
            3000,
        )

        submitted = st.form_submit_button("🔮 Prediksi Harga", use_container_width=True)

    if submitted:
        input_df = pd.DataFrame([{
            "Country": country,
            "Laptop Brand": brand,
            "Laptop Model": laptop_model,
            "CPU Brand": cpu_brand,
            "GPU Brand": gpu_brand,
            "GPU Model": gpu_model,
            "Usage Type": usage_type,
            "CPU Cores": cpu_cores,
            "CPU Threads": cpu_threads,
            "Base Clock (GHz)": base_clock,
            "Boost Clock (GHz)": boost_clock,
            "TDP (W)": tdp,
            "RAM (GB)": ram,
            "Storage (GB)": storage,
            "CPU Performance": cpu_perf,
            "GPU Performance": gpu_perf,
            "Total Performance": total_perf,
        }])

        pred_price = model.predict(input_df)[0]
        st.success(f"### 💰 Estimasi Harga: **${pred_price:,.2f}**")

        similar = df.iloc[(df["Total Performance"] - total_perf).abs().argsort()[:5]]
        st.caption("Laptop dengan performa mirip di dataset:")
        st.dataframe(
            similar[["Laptop Brand", "Laptop Model", "Usage Type", "Total Performance", "Price (USD)"]],
            use_container_width=True,
        )

st.divider()
st.caption("Dibuat dengan Streamlit • Model: scikit-learn & XGBoost • Data: dataset_laptop_realistis.csv")
